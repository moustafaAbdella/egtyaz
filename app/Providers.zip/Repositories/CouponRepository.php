<?php

namespace App\Repositories;


class CouponRepository extends BaseRepository{

    public function model()
    { 
       return ('App\\Copouns');
    }


}