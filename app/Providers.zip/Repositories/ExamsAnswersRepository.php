<?php

namespace App\Repositories;


class ExamsAnswersRepository extends BaseRepository{

    public function model()
    {
       return ('App\\Models\\examAnswers');
    }


}