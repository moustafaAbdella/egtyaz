<?php

namespace App\Repositories;


class QuestionsRepository extends BaseRepository{

    public function model()
    {
       return ('App\\Questions');
    }


}